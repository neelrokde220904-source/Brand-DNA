import React, { useState, useEffect } from 'react';
import { Bookmark, BookmarkCheck, BarChart2, Download, FileJson, SlidersHorizontal, Hexagon, Layers, Palette } from 'lucide-react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';
import useAppStore from '../store/appStore';
import { exportToPDF, exportToJSON } from '../utils/exportUtils';
import { BRAND_DATABASE } from '../data/brands';

export default function DNACard({ brand }) {
  const { savedBrands, saveBrand, addToBenchmark, setActiveBrand, axisOverrides, setAxisOverride } = useAppStore();
  const [editMode, setEditMode] = useState(false);
  const [localAxes, setLocalAxes] = useState(brand.designAxes);

  const isSaved = savedBrands.some((b) => b.brand === brand.brand);

  // Initialize local axes from overrides if they exist
  useEffect(() => {
    if (axisOverrides[brand.brand]) {
      setLocalAxes(axisOverrides[brand.brand]);
    } else {
      setLocalAxes(brand.designAxes);
    }
  }, [brand, axisOverrides]);

  const radarData = [
    { axis: 'Minimal↔Maximal', score: localAxes.minimalVsMaximal },
    { axis: 'Cold↔Warm', score: localAxes.coldVsWarm },
    { axis: 'Rigid↔Soft', score: localAxes.rigidVsSoft },
    { axis: 'Geometric↔Org.', score: localAxes.geometricVsOrganic },
    { axis: 'Loud↔Quiet', score: localAxes.loudVsQuiet },
  ];

  const axisLabel = (key) => {
    const labels = {
      minimalVsMaximal: 'Minimal ↔ Maximal',
      coldVsWarm: 'Cold ↔ Warm',
      rigidVsSoft: 'Rigid ↔ Soft',
      geometricVsOrganic: 'Geometric ↔ Organic',
      loudVsQuiet: 'Loud ↔ Quiet',
    };
    return labels[key] || key;
  };

  const handleSaveAxes = () => {
    setAxisOverride(brand.brand, localAxes);
    setEditMode(false);
  };

  const handleLoadComparable = (name) => {
    const found = BRAND_DATABASE.find((b) => b.brand.toLowerCase() === name.toLowerCase());
    if (found) {
      setActiveBrand(found);
    } else {
      alert(`"${name}" not in database`);
    }
  };

  const geo = brand.geometry;
  const surf = brand.surfaceLanguage;
  const cmf = brand.cmf;
  const qual = brand.qualitative;

  return (
    <div id="dna-card" className="w-full">
      {/* HEADER ROW */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <h2 style={{ fontFamily: 'General Sans' }} className="text-4xl font-semibold text-white">
            {brand.brand}
          </h2>
          <span className="liquid-glass rounded-full px-3 py-1 text-xs text-white/70 ml-3">
            {brand.category}
          </span>
        </div>

        <div className="flex gap-2">
          {isSaved ? (
            <button className="liquid-glass rounded-full px-3 py-2 text-xs text-white/50 flex items-center gap-1">
              <BookmarkCheck size={14} /> Saved
            </button>
          ) : (
            <button
              onClick={() => saveBrand(brand)}
              className="liquid-glass rounded-full px-3 py-2 text-xs text-white/70 hover:text-white flex items-center gap-1"
            >
              <Bookmark size={14} /> Save
            </button>
          )}
          <button
            onClick={() => addToBenchmark(brand)}
            className="liquid-glass rounded-full px-3 py-2 text-xs text-white/70 hover:text-white flex items-center gap-1"
          >
            <BarChart2 size={14} /> Benchmark
          </button>
          <button
            onClick={() => exportToPDF(brand.brand)}
            className="liquid-glass rounded-full px-3 py-2 text-xs text-white/70 hover:text-white flex items-center gap-1"
          >
            <Download size={14} /> PDF
          </button>
          <button
            onClick={() => exportToJSON(brand)}
            className="liquid-glass rounded-full px-3 py-2 text-xs text-white/70 hover:text-white flex items-center gap-1"
          >
            <FileJson size={14} /> JSON
          </button>
          <button
            onClick={() => setEditMode(!editMode)}
            className={`liquid-glass rounded-full px-3 py-2 text-xs flex items-center gap-1 transition-colors ${
              editMode ? 'text-purple-400' : 'text-white/70 hover:text-white'
            }`}
          >
            <SlidersHorizontal size={14} />
            {editMode ? 'Lock Axes' : 'Adjust Axes'}
          </button>
        </div>
      </div>

      {/* THREE PANEL GRID */}
      <div className="grid grid-cols-3 gap-4">
        {/* GEOMETRY PANEL */}
        <div className="glass-panel p-5">
          <div className="flex items-center gap-2 mb-4 text-white">
            <Hexagon size={14} /> <span className="font-semibold text-sm">Geometry</span>
          </div>
          <div className="space-y-3">
            <div className="text-sm">
              <span className="text-white/40 block text-xs">Form Vocabulary</span>
              <span className="text-white/90 leading-snug">{geo.formVocabulary}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/40 text-xs">Symmetry</span>
              <span className="liquid-glass px-2 py-0.5 rounded text-xs text-white/80">{geo.symmetryAxis}</span>
            </div>
            <div className="text-sm">
              <span className="text-white/40 block text-xs">Silhouette Type</span>
              <span className="text-white/90 leading-snug">{geo.silhouetteType}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/40 text-xs">Edge Tension</span>
              <span className="liquid-glass px-2 py-0.5 rounded text-xs text-white/80">{geo.edgeTension}</span>
            </div>
            <div className="text-sm">
              <span className="text-white/40 block text-xs">Proportion Ratio</span>
              <span className="text-white/90">{geo.proportionRatio}</span>
            </div>
            <div className="pt-2">
              <div className="flex justify-between items-center mb-1">
                <span className="text-white/40 text-xs">Corner Radius</span>
                <span className="text-xs text-white/80">{geo.cornerRadiusIndex}/10</span>
              </div>
              <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div className="axis-bar-fill" style={{ width: `${(geo.cornerRadiusIndex / 10) * 100}%` }} />
              </div>
            </div>
            <p className="text-xs text-white/50 italic mt-3 leading-relaxed border-t border-white/10 pt-3">
              "{geo.geometryNarrative}"
            </p>
          </div>
        </div>

        {/* SURFACE PANEL */}
        <div className="glass-panel p-5">
          <div className="flex items-center gap-2 mb-4 text-white">
            <Layers size={14} /> <span className="font-semibold text-sm">Surface Language</span>
          </div>
          <div className="space-y-3">
            <div className="text-sm">
              <span className="text-white/40 block text-xs">Line Logic</span>
              <span className="text-white/90 leading-snug">{surf.lineLogic}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/40 text-xs">Seam Philosophy</span>
              <span className="liquid-glass px-2 py-0.5 rounded text-xs text-white/80">{surf.seamPhilosophy}</span>
            </div>
            <div className="text-sm">
              <span className="text-white/40 block text-xs">Affordance</span>
              <span className="text-white/90 leading-snug">{surf.affordanceLanguage}</span>
            </div>
            <div className="text-sm">
              <span className="text-white/40 block text-xs">Texture Grain</span>
              <span className="text-white/90">{surf.textureGrain}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/40 text-xs">Graphics</span>
              <span className="liquid-glass px-2 py-0.5 rounded text-xs text-white/80">{surf.graphicIntegration}</span>
            </div>
            <div className="pt-2">
              <div className="flex justify-between items-center mb-1">
                <span className="text-white/40 text-xs">Detail Density</span>
                <span className="text-xs text-white/80">{surf.detailDensity}/10</span>
              </div>
              <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div className="axis-bar-fill" style={{ width: `${(surf.detailDensity / 10) * 100}%` }} />
              </div>
            </div>
            <p className="text-xs text-white/50 italic mt-3 leading-relaxed border-t border-white/10 pt-3">
              "{surf.surfaceNarrative}"
            </p>
          </div>
        </div>

        {/* CMF PANEL */}
        <div className="glass-panel p-5">
          <div className="flex items-center gap-2 mb-4 text-white">
            <Palette size={14} /> <span className="font-semibold text-sm">CMF Direction</span>
          </div>
          <div className="space-y-4">
            <div>
              <span className="text-white/40 block text-xs mb-2">Primary Palette</span>
              <div className="flex gap-2 flex-wrap">
                {cmf.primaryPalette.map((hex) => (
                  <div
                    key={hex}
                    className="w-8 h-8 rounded-md cursor-pointer hover:scale-110 transition-transform relative group border border-white/10 shadow-sm"
                    style={{ backgroundColor: hex }}
                  >
                    <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[10px] text-white/80 bg-black/80 px-1 py-0.5 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap z-10 pointer-events-none">
                      {hex}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <span className="text-white/40 block text-xs mb-2">Accent Palette</span>
              <div className="flex gap-2 flex-wrap">
                {cmf.accentPalette.map((hex) => (
                  <div
                    key={hex}
                    className="w-6 h-6 rounded-md cursor-pointer hover:scale-110 transition-transform relative group border border-white/10 shadow-sm"
                    style={{ backgroundColor: hex }}
                  >
                    <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[10px] text-white/80 bg-black/80 px-1 py-0.5 rounded opacity-0 group-hover:opacity-100 whitespace-nowrap z-10 pointer-events-none">
                      {hex}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <div className="text-sm">
              <span className="text-white/40 block text-xs">Material Family</span>
              <span className="text-white/90 leading-snug">{cmf.materialFamily}</span>
            </div>
            <div className="text-sm">
              <span className="text-white/40 block text-xs">Hero Material</span>
              <span className="text-purple-300 font-medium">{cmf.heroMaterial}</span>
            </div>
            <div className="text-sm">
              <span className="text-white/40 block text-xs">Finish Type</span>
              <span className="text-white/90">{cmf.finishType}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/40 text-xs">Tactility</span>
              <span className="liquid-glass px-2 py-0.5 rounded text-xs text-white/80">{cmf.tactility}</span>
            </div>
            <p className="text-xs text-white/50 italic mt-3 leading-relaxed border-t border-white/10 pt-3">
              "{cmf.cmfNarrative}"
            </p>
          </div>
        </div>
      </div>

      {/* DESIGN AXES ROW */}
      <div className="glass-panel p-6 mt-4 grid grid-cols-2 gap-8 items-center">
        {/* LEFT — Radar Chart or Sliders */}
        <div className="relative">
          <h3 className="text-white font-semibold text-sm mb-4 absolute top-0 left-0 z-10">Design Positioning</h3>
          
          {editMode ? (
            <div className="pt-8 space-y-4">
              {Object.entries(localAxes).map(([key, val]) => (
                <div key={key} className="flex items-center gap-3 text-sm">
                  <span className="text-white/60 w-32 text-xs">{axisLabel(key)}</span>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={val}
                    onChange={(e) =>
                      setLocalAxes({
                        ...localAxes,
                        [key]: Number(e.target.value),
                      })
                    }
                    className="flex-1"
                  />
                  <span className="text-white/80 w-4 text-xs font-mono">{val}</span>
                </div>
              ))}
              <button
                onClick={handleSaveAxes}
                className="liquid-glass rounded-full px-4 py-2 text-sm text-white mt-4 w-full hover:bg-white/10 transition-colors"
              >
                Save Adjustments
              </button>
            </div>
          ) : (
            <div className="pt-4 -ml-6 -mb-6">
              <ResponsiveContainer width="100%" height={280}>
                <RadarChart data={radarData} margin={{ top: 20, right: 30, bottom: 20, left: 30 }}>
                  <PolarGrid gridType="polygon" stroke="rgba(255,255,255,0.08)" />
                  <PolarAngleAxis
                    dataKey="axis"
                    tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11, fontFamily: 'Geist Sans' }}
                  />
                  <Radar
                    dataKey="score"
                    stroke="#6366f1"
                    strokeWidth={2}
                    fill="#6366f1"
                    fillOpacity={0.25}
                    isAnimationActive={false}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* RIGHT — Qualitative */}
        <div className="border-l border-white/5 pl-8">
          <h3 className="text-white font-semibold text-sm mb-3">DNA Synthesis</h3>
          <p className="text-sm text-white/80 leading-6 mb-5">{qual.dnaSummary}</p>

          <div className="mb-5">
            <span className="text-white/40 block text-xs mb-2">Key Identifiers</span>
            <div className="flex flex-wrap gap-2">
              {qual.designKeywords.map((kw) => (
                <span key={kw} className="liquid-glass rounded-full px-3 py-1 text-xs text-white/70">
                  {kw}
                </span>
              ))}
            </div>
          </div>

          <div className="mb-5">
            <span className="text-white/40 block text-xs mb-2">Comparable DNA</span>
            <div className="flex gap-2">
              {qual.comparableBrands.map((name) => (
                <button
                  key={name}
                  onClick={() => handleLoadComparable(name)}
                  className="liquid-glass rounded-full px-3 py-1 text-xs text-white/70 hover:text-white transition-colors"
                >
                  {name}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-4">
            <span className="text-white/40 block text-xs mb-1">Differentiation Signal</span>
            <p className="text-xs text-white/80 leading-5">{qual.differentiationSignal}</p>
          </div>

          <div>
            <span className="text-white/40 block text-xs mb-1">Era & Trend Positioning</span>
            <p className="text-xs text-white/60 italic leading-5">{qual.eraTrendPositioning}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
